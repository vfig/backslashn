The Door Challenge II by vfig

An entry for the mapcore.org Door Challenge 2018.

A nuclear missile's headed your way. A nuclear bunker is right behind
you. But its door is shut. You have two minutes to find a way inside.

It may take you a few tries to figure out how to get into the bunker.
But two minutes is easily plenty of time, once you know the solution.

SPOILER ALERT! Solution can be viewed at: https://www.youtube.com/watch?v=CH4JklpLcio


--------------
HOW TO INSTALL
--------------

o  Locate your Half-Life 2 directory:
   -  Open Steam to the Library tab.
   -  Right-click on Half-Life 2, and select Properties.
   -  Select the Local Files tab.
   -  Click on Browse Local Files.

o  Browse to the hl2\maps subfolder.

o  Copy the door2_vfig.bsp file into there.


-----------
HOW TO PLAY
-----------

o  Launch Half-Life 2.

o  Enable the console:
   - At the main menu, select Options.
   - Select the Keyboard tab.
   - Click on Advanced.
   - Make sure Enable Developer Console is checked.
   - Click OK, then OK again.

o  Open the console with backquote (`)

o  Type the following command and press enter: map door2_vfig


-------
CREDITS
-------

Concept, design, and scripting by vfig (Andy Durdin).
Original conversation system scripting also by vfig.
Environment art courtesy of Half-Life 2's Highway 17.
All art and sound is stock Half-Life 2 assets.
Seagull appears courtesy of LOOM(tm).


----------
DISCLAIMER
----------

No goblin commoners or royalty were harmed in the making of this product.

